import random

# Ask user how much they would like to spend; must be greater than or equal to $1 and less than $10
print("Welcome to the unicorn game, press <enter> to continue.")
amount_spend = float(input("How much would you like to spend? (Between $1 and $10) "))

# Check if the amount is valid
if amount_spend < 1 or amount_spend >= 10:
    print("Please enter an amount of money between $1 and $10.")
else:
    input("You are good to go. Press <Enter> to proceed.")

# Set up initial total as the amount spent
total = amount_spend

keep_going = ""
while keep_going == "":
    # List of characters (tokens) and weights
    generated_character = ["zebra", "horse", "unicorn", "donkey"]
    weights = [0.24, 0.25, 0.01, 0.5]  # The house has an advantage by making unicorn rare and donkey common

    # Randomly select a character (token)
    num_characters = int(amount_spend)  # Convert amount_spend to an integer for number of tokens
    generated_characters = random.choices(generated_character, weights=weights, k=num_characters)
    
    # Print the generated characters
    print("Generated Characters: ", generated_characters)

    # Initialize amount_won for this round
    amount_won = 0

    # Process each generated character and update the total based on the token
    for token in generated_characters:
        if token == "zebra" or token == "horse":
            total -= 0.5
            amount_won = 0.5
        elif token == "unicorn":
            total += 5
            amount_won = 5
        elif token == "donkey":
            total -= 1
            amount_won = 0

    # Provide feedback based on the winning amount
    if amount_won > 0:
        print(f"Congratulations, you won ${amount_won:.2f}!")
    else:
        print("Sorry, you did not win anything this round.")

    # Display the new total
    print(f"Your new total: ${total:.2f}")

    # If the total is more than $1.00, output farewell message and end the game
    if total > 1:
        print("Farewell! You've ended the game with more than $1.00.")
        break

    # Ask the user if they want to continue playing
    keep_going = input("Do you want to continue playing? (Press <Enter> to continue or type 'no' to stop): ")
    if keep_going.lower() == 'no':
        break

print("Thanks for playing! Goodbye!")